namespace pensions
{
    partial class pensionsDataContext
    {
    }
}
